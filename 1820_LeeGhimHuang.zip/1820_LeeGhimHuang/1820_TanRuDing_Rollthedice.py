playerName= raw_input("Enter Player Name: ") #Get player's name
dice=[ ] #Number generated will be stored in an array
nTimesRolled=0 #number of chances
min=1
max=6

while True:
    try:
        guess= int(input("Please guess a number from 1 to 6: "))
    except:
        print("Enter integer value ONLY")
    else:
        import random #Program will generate random number from 1 to 6
        for x in range(1): #1 value from range
            print ('dice rolled',random.randint(1,6))#range from 1-6


   
    nTimesRolled=nTimesRolled+1#increment counter
                
    if nTimesRolled==6:
        break
    
if dice==["6", "6", "3","3", "1", "1"]:
    print("You are in luck.")
else:
    print("Too bad. Better luck another time.")

    



