print("==================================")
print("Welcome to the Musical Chair Game")
print("===================================")
num_player=int(input("How many players are there?:"))#to get number of players
player_name=[None]*num_player#initialize array
numchair=num_player+1#to get number of chairs
for i in range(num_player):
     player_name[i]=raw_input("Enter player's name:")#loop to get all the player's names
while True:
    numchair=numchair-1#to decrement number of chairs
    num_player=num_player-1#to decrement number of players
    print("Music is playing")
    import time
    time.sleep(3)#to pause program while music is playing
    import random
    x=random.randint(0,num_player)#generate random number from array
    print(player_name[x] ,"lost")
    player_name.pop(x)#remove element from array
    if num_player==1:#loop to end game when one player is left
        break
print (player_name[x], "won")
     

