﻿print ("HELLO WORLD")

print ("WELCOME TO GUESS A COLOR GAME")

print("YOU HAVE TO ENTER A COLOR TO GUESS")

from random import randint

colors = ['red', 'blue', 'black', 'pink']

generator = randint(0,len(colors)-1)

guess = input('guess a color: ')

chance = 3

while True: #you want to keep guessing until you actually get it

    if guess != colors[generator]:

        chance =chance -1

        print('wrong, try again')

        guess = input('guess a color: ').strip() #strip() here removes spaces

    if guess == colors[generator] or chance == 0:

        break




print('sucess: ' + colors[generator])